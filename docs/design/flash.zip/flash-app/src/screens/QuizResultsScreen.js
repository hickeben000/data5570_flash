import React, { useEffect } from "react";
import {
  ActivityIndicator,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useDispatch, useSelector } from "react-redux";

import { fetchQuiz } from "../store/quizzesSlice";
import formatError from "../utils/formatError";

function getCorrectAnswerText(question) {
  if (question.question_type === "free_response") {
    return "Open-ended response graded by AI.";
  }
  const correctChoices = (question.answer_choices || [])
    .filter((choice) => choice.is_correct)
    .map((choice) => choice.choice_text);
  return correctChoices.join(", ") || "Not available";
}

function getUserAnswerText(question) {
  if (question.question_type === "mc") {
    const selectedChoice = (question.answer_choices || []).find(
      (choice) => String(choice.id) === String(question.user_answer)
    );
    return selectedChoice?.choice_text || "(no answer)";
  }
  return question.user_answer || "(no answer)";
}

export default function QuizResultsScreen({ route }) {
  const { quizId } = route.params;
  const dispatch = useDispatch();
  const { quiz, loading, error } = useSelector((state) => state.quizzes);

  useEffect(() => {
    const hasLoadedResults =
      quiz &&
      quiz.id === quizId &&
      quiz.completed_at &&
      Array.isArray(quiz.questions);

    if (!hasLoadedResults) {
      dispatch(fetchQuiz(quizId));
    }
  }, [dispatch, quizId, quiz]);

  if (loading && (!quiz || quiz.id !== quizId)) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#4361ee" />
      </View>
    );
  }

  if (!quiz || quiz.id !== quizId) {
    return (
      <View style={styles.center}>
        <Text style={styles.error}>{formatError(error) || "Unable to load results."}</Text>
      </View>
    );
  }

  const questions = quiz.questions || [];

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.heading}>Quiz Results</Text>
      <Text style={styles.score}>
        Score: {quiz.score != null ? `${quiz.score.toFixed(1)}%` : "N/A"}
      </Text>
      {error ? <Text style={styles.error}>{formatError(error)}</Text> : null}

      {questions.map((question, index) => (
        <View
          key={question.id}
          style={[
            styles.questionBlock,
            question.is_correct ? styles.correct : styles.incorrect,
          ]}
        >
          <Text style={styles.qNumber}>Question {index + 1}</Text>
          <Text style={styles.qText}>{question.question_text}</Text>

          <Text style={styles.answerLabel}>Your answer</Text>
          <Text style={styles.answerText}>{getUserAnswerText(question)}</Text>

          <Text style={styles.answerLabel}>Expected answer</Text>
          <Text style={styles.answerText}>{getCorrectAnswerText(question)}</Text>

          {question.feedback ? (
            <View style={styles.feedbackBox}>
              <Text style={styles.feedbackLabel}>Feedback</Text>
              <Text style={styles.feedbackText}>{question.feedback}</Text>
            </View>
          ) : null}

          <View style={styles.explanationBox}>
            <Text style={styles.explanationLabel}>Explanation</Text>
            <Text style={styles.explanationText}>
              {question.explanation || "No explanation was returned."}
            </Text>
          </View>
        </View>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#f5f7fb" },
  content: { padding: 24, paddingBottom: 40 },
  center: { flex: 1, justifyContent: "center", alignItems: "center", padding: 24 },
  heading: {
    fontSize: 26,
    fontWeight: "800",
    color: "#1a1a2e",
    marginBottom: 8,
  },
  score: {
    fontSize: 32,
    fontWeight: "800",
    color: "#4361ee",
    textAlign: "center",
    marginBottom: 24,
  },
  error: {
    color: "#c0392b",
    marginBottom: 12,
  },
  questionBlock: {
    borderRadius: 14,
    padding: 18,
    marginBottom: 16,
    borderLeftWidth: 4,
  },
  correct: {
    backgroundColor: "#eafaf1",
    borderLeftColor: "#2ecc71",
  },
  incorrect: {
    backgroundColor: "#fdf2f2",
    borderLeftColor: "#e74c3c",
  },
  qNumber: {
    fontSize: 12,
    fontWeight: "700",
    color: "#4361ee",
    textTransform: "uppercase",
    marginBottom: 6,
  },
  qText: { fontSize: 16, color: "#1a1a2e", marginBottom: 12, lineHeight: 22 },
  answerLabel: {
    fontSize: 12,
    fontWeight: "700",
    color: "#6b7280",
    marginTop: 4,
  },
  answerText: { fontSize: 15, color: "#333", marginBottom: 4 },
  feedbackBox: {
    backgroundColor: "rgba(67,97,238,0.08)",
    borderRadius: 10,
    padding: 12,
    marginTop: 10,
  },
  feedbackLabel: {
    fontSize: 12,
    fontWeight: "700",
    color: "#4361ee",
    marginBottom: 4,
  },
  feedbackText: { fontSize: 14, color: "#374151", lineHeight: 20 },
  explanationBox: {
    backgroundColor: "rgba(0,0,0,0.03)",
    borderRadius: 10,
    padding: 12,
    marginTop: 10,
  },
  explanationLabel: {
    fontSize: 12,
    fontWeight: "700",
    color: "#4361ee",
    marginBottom: 4,
  },
  explanationText: { fontSize: 14, color: "#555", lineHeight: 20 },
});
